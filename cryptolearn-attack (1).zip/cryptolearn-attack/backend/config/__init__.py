# Configuration package for CryptoLearn backend
